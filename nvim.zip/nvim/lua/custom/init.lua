local set = vim.opt

set.colorcolumn = "80"
set.tabstop = 4
set.shiftwidth = 4
set.foldmethod = "indent"
set.foldlevel = 99

vim.api.nvim_exec([[
function FormatBuffer()
    if &modified && !empty(findfile('.clang-format', expand('%:p:h') . ';'))
        let cursor_pos = getpos('.')
        :%!clang-format
        call setpos('.', cursor_pos)
    endif
endfunction
]], false)

vim.cmd("autocmd BufWritePre *.h,*.hpp,*.c,*.cpp,*.vert,*.frag,*.glsl :call FormatBuffer()")
vim.cmd("autocmd BufWritePost *.go silent !gofmt -s -w .")
vim.cmd("autocmd BufWritePost *.go silent !goimports -w .")
